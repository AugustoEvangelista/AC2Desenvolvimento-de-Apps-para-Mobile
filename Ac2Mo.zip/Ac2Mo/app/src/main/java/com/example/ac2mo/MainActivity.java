package com.example.ac2mo;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    EditText edtTitulo, edtDiretor, edtAno, edtNota;
    Spinner spGenero;
    CheckBox chkCinema;
    Button btnSalvar, btnFiltrar;
    ListView listView;

    DatabaseHelper db;
    ArrayAdapter<String> adapter;
    ArrayList<Filme> listaFilmes;
    String generoSelecionado = "Todos";
    int idSelecionado = -1; // para edição

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        db = new DatabaseHelper(this);

        edtTitulo = findViewById(R.id.edtTitulo);
        edtDiretor = findViewById(R.id.edtDiretor);
        edtAno = findViewById(R.id.edtAno);
        edtNota = findViewById(R.id.edtNota);
        spGenero = findViewById(R.id.spGenero);
        chkCinema = findViewById(R.id.chkCinema);
        btnSalvar = findViewById(R.id.btnSalvar);
        btnFiltrar = findViewById(R.id.btnFiltrar);
        listView = findViewById(R.id.listView);

        String[] generos = {"Todos", "Ação", "Drama", "Comédia", "Ficção", "Terror"};
        ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, generos);
        spGenero.setAdapter(spinnerAdapter);

        carregarLista();

        btnSalvar.setOnClickListener(v -> salvarOuAtualizar());
        btnFiltrar.setOnClickListener(v -> {
            generoSelecionado = spGenero.getSelectedItem().toString();
            carregarLista();
        });

        listView.setOnItemClickListener((parent, view, position, id) -> {
            Filme f = listaFilmes.get(position);
            idSelecionado = f.getId();
            edtTitulo.setText(f.getTitulo());
            edtDiretor.setText(f.getDiretor());
            edtAno.setText(String.valueOf(f.getAno()));
            edtNota.setText(String.valueOf(f.getNota()));
            chkCinema.setChecked(f.isViuNoCinema());
            for (int i = 0; i < spGenero.getCount(); i++) {
                if (spGenero.getItemAtPosition(i).toString().equals(f.getGenero())) {
                    spGenero.setSelection(i);
                    break;
                }
            }
        });

        listView.setOnItemLongClickListener((parent, view, position, id) -> {
            Filme f = listaFilmes.get(position);
            db.deletarFilme(f.getId());
            Toast.makeText(this, "Filme excluído!", Toast.LENGTH_SHORT).show();
            carregarLista();
            return true;
        });
    }

    void salvarOuAtualizar() {
        String titulo = edtTitulo.getText().toString().trim();
        String diretor = edtDiretor.getText().toString().trim();
        String anoStr = edtAno.getText().toString().trim();
        String notaStr = edtNota.getText().toString().trim();

        if (titulo.isEmpty()) {
            Toast.makeText(this, "Informe o título!", Toast.LENGTH_SHORT).show();
            return;
        }

        int ano;
        float nota;

        try {
            ano = Integer.parseInt(anoStr);
        } catch (Exception e) {
            Toast.makeText(this, "Ano inválido!", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            nota = Float.parseFloat(notaStr);
            if (nota < 1 || nota > 5) {
                Toast.makeText(this, "A nota deve ser entre 1 e 5!", Toast.LENGTH_SHORT).show();
                return;
            }
        } catch (Exception e) {
            Toast.makeText(this, "Nota inválida!", Toast.LENGTH_SHORT).show();
            return;
        }

        String genero = spGenero.getSelectedItem().toString();
        boolean cinema = chkCinema.isChecked();

        Filme f = new Filme(idSelecionado, titulo, diretor, ano, nota, genero, cinema);

        if (idSelecionado == -1) {
            db.inserirFilme(f);
            Toast.makeText(this, "Filme salvo!", Toast.LENGTH_SHORT).show();
        } else {
            db.atualizarFilme(f);
            Toast.makeText(this, "Filme atualizado!", Toast.LENGTH_SHORT).show();
            idSelecionado = -1;
        }

        limparCampos();
        carregarLista();
    }

    void carregarLista() {
        listaFilmes = db.listarFilmes(generoSelecionado);
        ArrayList<String> titulos = new ArrayList<>();

        for (Filme f : listaFilmes) {
            titulos.add(f.getTitulo() + " (" + f.getAno() + ") - " + f.getGenero() + " ★" + f.getNota());
        }

        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, titulos);
        listView.setAdapter(adapter);
    }

    void limparCampos() {
        edtTitulo.setText("");
        edtDiretor.setText("");
        edtAno.setText("");
        edtNota.setText("");
        chkCinema.setChecked(false);
        spGenero.setSelection(0);
    }
}
